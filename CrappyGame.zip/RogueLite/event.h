#ifndef EVENT_H_INCLUDED
#define EVENT_H_INCLUDED
#include <SDL.h>

typedef struct
{
    SDL_Keycode clavier[100];
    int mousex,mousey;
    int mousexrel,mouseyrel;
    char mousebuttons[6];
    char quit;
} Entree;

void UpdateEvents(Entree* in);

#endif // EVENT_H_INCLUDED
