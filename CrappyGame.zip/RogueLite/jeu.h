#ifndef JEU_H_INCLUDED
#define JEU_H_INCLUDED
#include <SDL.h>
#include <SDL_image.h>

SDL_Renderer *renderer;

typedef enum {MARCHE} Etat;
typedef enum {JOUEUR} PersoType;

typedef struct {
    SDL_Texture* texture;
    int dimension;
} Image;

typedef struct {
    Image* img;
    int nbFrame;
    int msParFrame;
}Anim;

typedef struct s_AnimNoeud AnimNoeud;

struct s_AnimNoeud {
    Anim* animation;
    int x;
    int y;
    int tpsDebut;
    AnimNoeud* suivant;
};

typedef struct {
    PersoType type;
    Etat etat;
    int vie;
    double x;
    double y;
    double vitesse;
    SDL_Rect hitbox;
    int derniereAttaque;
}Personnage;

Image* init_img(char* nomImg, int dim);

Uint32 fps(Uint32 temps);

void aff_img(Image* img, int x, int y, int numImg);

Anim* init_anim(char* nom, int dim, int nbFrame, int msParFrame);

void jouer_anim(Anim* anim, int x, int y);

void aff_anim();

void jouer(void);

Personnage* init_perso(PersoType type);

void attaque_droite(Personnage* player);

#endif // JEU_H_INCLUDED
