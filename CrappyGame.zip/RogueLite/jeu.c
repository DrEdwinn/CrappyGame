#include "jeu.h"
#include "event.h"
#include "carte.h"
#include <stdio.h>
#include <stdlib.h>

SDL_Window* fenetre;
SDL_Renderer *renderer;
Image* perso;
Anim* frappe;
AnimNoeud* animationsListe;

void jouer(void){

    Uint32 tps=SDL_GetTicks();
    int nb=0;
    Entree in;
    memset(&in,0,sizeof(in));//Initialisation
    perso = init_img("images/chevalierSprite.png", 64);
    Personnage* player = init_perso(JOUEUR);

    animationsListe=malloc(sizeof(AnimNoeud));
    frappe=malloc(sizeof(Anim));
    animationsListe->suivant=NULL;
    frappe->img=init_img("images/frappe.png",64);
    frappe->msParFrame=30;
    frappe->nbFrame=3;



    charger_carte();
    imprimer_carte();


    while(!in.clavier[SDLK_ESCAPE] && !in.quit)
    {
        UpdateEvents(&in);
        if (in.clavier[SDLK_UP])
                {
                    avance_haut(player);
                    nb=14+SDL_GetTicks()/100%2;
                    //if (hitbox_haut(player->x,player->y)) {player->y-=player->vitesse;nb=14+SDL_GetTicks()/100%2;}
                }
        if (in.clavier[SDLK_LEFT])
                {
                    nb=10+SDL_GetTicks()/100%4;
                    avance_gauche(player);
                    //if (hitbox_gauche(player->x,player->y)){player->x-=player->vitesse;nb=10+SDL_GetTicks()/100%4;}

                }
        if (in.clavier[SDLK_RIGHT])
                {
                    avance_droite(player);
                    nb=SDL_GetTicks()/100%4;
                    //if (hitbox_droite(player->x,player->y)) {player->x+=player->vitesse;nb=SDL_GetTicks()/100%4;}

                }
        if (in.clavier[SDLK_DOWN])
                {
                    avance_bas(player);
                    nb=4+SDL_GetTicks()/100%6;
                    //if (hitbox_bas(player->x,player->y)) {player->y+=player->vitesse;nb=4+SDL_GetTicks()/100%6;}

                }
        if (in.clavier[SDLK_1]){
            attaque_droite(player);
        }
        if (in.clavier[SDLK_2]){
            player->vitesse=8;
        }
        else{
            player->vitesse=2.5;
        }


    SDL_RenderClear(renderer);

    aff_carte();
    aff_img(perso,(int)(player->x),(int)(player->y),nb);
    aff_anim();
    tps=fps(tps);

    SDL_RenderPresent(renderer);

    }
    SDL_DestroyRenderer(renderer);
}

Image* init_img(char* nomImg, int dim){
    Image* img=malloc(sizeof(Image));
    SDL_Surface* sprite = IMG_Load(nomImg);
    if (!sprite){
        printf("erreur : %s", IMG_GetError());
        exit(0);
    }
    SDL_Texture* tex = SDL_CreateTextureFromSurface(renderer, sprite);
    if(!tex){
        printf("erreur : %s", SDL_GetError());
        exit(0);
    }
    SDL_FreeSurface(sprite);
    img->dimension=dim;
    img->texture=tex;
    return img;
}

void aff_img(Image* img, int x, int y, int numImg){
    int err;
    SDL_Rect surf, coord;
    surf.h=img->dimension;
    surf.w=img->dimension;
    surf.y=0;
    surf.x=img->dimension*numImg;
    coord.x=x;
    coord.y=y;
    coord.h=TAILLE_CEL;
    coord.w=TAILLE_CEL;

    err=SDL_RenderCopy(renderer, img->texture, &surf, &coord);
    if (err==-1){
        printf("%s", SDL_GetError());
        exit(0);
    }

}

Anim* init_anim(char* nom, int dim, int nbFrame, int msParFrame){
    Anim* anim=malloc(sizeof(Anim));
    anim->img=init_img(nom,dim);
    anim->msParFrame;
    anim->nbFrame;
    return anim;
}

void jouer_anim(Anim* anim, int x, int y){
    AnimNoeud* noeud= malloc(sizeof(AnimNoeud));
    AnimNoeud* ptr;
    noeud->suivant=NULL;
    noeud->animation=anim;
    noeud->tpsDebut=SDL_GetTicks();
    noeud->x=x;
    noeud->y=y;
    ptr=animationsListe;
    while(ptr->suivant!=NULL){
        ptr=ptr->suivant;
    }
    if (ptr!=NULL) ptr->suivant=noeud;
}

void aff_anim(){
    AnimNoeud* ptr=animationsListe, *ptr2;
    int numFrame;
    while(ptr != NULL && ptr->suivant!=NULL){
        numFrame=(SDL_GetTicks()-ptr->suivant->tpsDebut)/ptr->suivant->animation->msParFrame;
        if(numFrame>=ptr->suivant->animation->nbFrame){
            ptr2=ptr;
            ptr->suivant=ptr->suivant->suivant;
            free(ptr2->suivant);
            printf("ho\n");
        }
        else{

            aff_img(ptr->suivant->animation->img,ptr->suivant->x,ptr->suivant->y,numFrame);
            ptr=ptr->suivant;
            printf("1\n");

        }
        printf("2\n");

    }
}



Uint32 fps(Uint32 temps){
    Uint32 temps2, intervalle=0;
    temps2=SDL_GetTicks();
    intervalle=(temps2-temps);
    if (intervalle<16) {SDL_Delay(16-intervalle);}
    temps2=SDL_GetTicks();
    return temps2;
}

Personnage* init_perso(PersoType type){
    Personnage* perso=malloc(sizeof(Personnage));
    perso->type=type;
    perso->etat=MARCHE;
    switch (type) {
    case JOUEUR:
        perso->vie=5;
        perso->hitbox.x=8;
        perso->hitbox.y=32;
        perso->hitbox.w=48;
        perso->hitbox.h=32;
        break;
    default:
        perso->vie=5;
        perso->hitbox.x=8;
        perso->hitbox.y=32;
        perso->hitbox.w=48;
        perso->hitbox.h=32;
        break;
        }
    perso->x=0;
    perso->y=0;
    perso->vitesse=2.5;
    return perso;
}

void attaque_droite(Personnage* player){
    int temps=SDL_GetTicks();
    if (temps-player->derniereAttaque>1000){
        player->derniereAttaque=temps;
        jouer_anim(frappe, player->x+3*TAILLE_CEL/4, player->y);

    }
}


