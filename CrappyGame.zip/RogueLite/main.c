#include <SDL.h>
#include <SDL_image.h>
#include <stdio.h>
#include <stdlib.h>

SDL_Window* fenetre;
SDL_Renderer *renderer;

int main(int argc, char* argv[]){
    if (SDL_Init(SDL_INIT_VIDEO) != 0 )
    {
        fprintf(stdout,"�chec de l'initialisation de la SDL (%s)\n",SDL_GetError());
    }
    IMG_Init(IMG_INIT_PNG);
    {
        fenetre = SDL_CreateWindow("Le jeu",SDL_WINDOWPOS_UNDEFINED,SDL_WINDOWPOS_UNDEFINED,1366,768,SDL_WINDOW_SHOWN | SDL_WINDOW_FULLSCREEN);
        if(!fenetre){
            fprintf(stderr,"Erreur de cr�ation de la fen�tre: %s\n",SDL_GetError());
        }
        else{
            renderer = SDL_CreateRenderer(fenetre,-1,SDL_RENDERER_ACCELERATED);
            jouer();
        }
    }



    //Quitter
    SDL_DestroyWindow(fenetre);
    IMG_Quit();
    SDL_Quit();
    return 1;

}
