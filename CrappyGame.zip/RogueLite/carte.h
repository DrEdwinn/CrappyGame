#ifndef CARTE_H_INCLUDED
#define CARTE_H_INCLUDED

#include "jeu.h"

#define TAILLE_CEL 64
#define CARTE_LARGEUR 21
#define CARTE_LONGUEUR 12

typedef enum {VIDE, MUR, EAU, CARRELAGE, HERBE} Cellule;

typedef struct {
    Cellule map_cel[CARTE_LONGUEUR][CARTE_LARGEUR];
} Carte;

Carte carte;

void charger_carte(void);

void aff_carte(void);

void imprimer_cel(Cellule cel);

int est_obstacle(Cellule cel);

void avance_droite(Personnage* player);

void avance_gauche(Personnage* player);

void avance_haut(Personnage* player);

void avance_bas(Personnage* player);

int nb_bordure(int i, int j);

#endif // CARTE_H_INCLUDED
